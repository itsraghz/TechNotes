Please execute the files in the following order in the Groovy Console or in the
command prompt / shell


Command to execute : groovy <fileName>[.groovy]

Note: The file extension ".groovy" is optional when you execute a groovy file

1. JsonLiteral 
2. JsonFromPOGO  
3. JsonSlurper1Basic  
4. JsonSlurper2List  
5. JsonSlurper3DataTypes  
6. JsonSlurper4File
7. JsonBuilder1Basic  
8. JsonBuilder2File  

